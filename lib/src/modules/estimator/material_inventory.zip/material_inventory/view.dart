import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:smart_construction/src/utils/app_color.dart';
import 'package:smart_construction/src/utils/app_icons.dart';
import 'package:smart_construction/src/widgets/app_button.dart';
import '../../../widgets/app_appbar.dart';
import 'logic.dart';

class MaterialInventoryView extends StatelessWidget {
  const MaterialInventoryView({super.key});

  @override
  Widget build(BuildContext context) {
    return GetBuilder(
      init: MaterialInventoryLogic(),
      builder: (logic){
      return Scaffold(
        appBar: AppPrimaryBar(
          title: 'Material Inventory',
          showBackButton: true,
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Warehouse / yard stock, receiving, issuing, and cycle counts.',
                style: TextStyle(fontSize: 12, color: AppColors.textMuted),
              ),
              SizedBox(height: 10,),
              Row(
                children: [
                  Expanded(
                    child: CustomIconButton(
                        text: 'Add',
                        icon: AppIcons.add,
                        onPressed: (){},
                    ),
                  ),
                  SizedBox(width: 8,),
                  Expanded(
                    child: CustomIconButton(
                        text: 'Location',
                        icon: AppIcons.location,
                        onPressed: (){},
                        color: Colors.grey.shade400,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 13,),
              Text('Barcode / QR Scan', style: TextStyle(fontWeight: FontWeight.w600),),
              SizedBox(height: 5,),
              Text('Type or scan a barcode/SKU to look up on-hand.',
                style: TextStyle(fontSize: 12, color: AppColors.textMuted),
              ),
              SizedBox(height: 10,),

            ],
          ),
        ),
      );
    });
  }
}
