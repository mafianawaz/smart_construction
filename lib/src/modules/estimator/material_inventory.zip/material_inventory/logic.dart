import 'package:get/get.dart';

class MaterialInventoryLogic extends GetxController{

}